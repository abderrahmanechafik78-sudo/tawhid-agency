import base64
parts = []
for i in range(1,6):
    with open(f'/tmp/c{i}.b64') as f:
        parts.append(f.read())
data = base64.b64decode(''.join(parts))
with open('/home/prof/tawhid-agency/index.html','wb') as f:
    f.write(data)
with open('/home/prof/tawhid-backend/public/index.html','wb') as f:
    f.write(data)
print('done - written to tawhid-agency and tawhid-backend/public')
